﻿namespace Calculadora
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declaração das variáveis
            double num1, num2, resultado;
            int operacao;

            // Solicitando os dois números
            Console.WriteLine("Digite o primeiro número:");
            num1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o segundo número:");
            num2 = double.Parse(Console.ReadLine());

            // Solicitando a operação
            Console.WriteLine("\nEscolha a operação:");
            Console.WriteLine("1 - Soma");
            Console.WriteLine("2 - Subtração");
            Console.WriteLine("3 - Divisão");
            Console.WriteLine("4 - Multiplicação");
            Console.Write("Digite o número da operação (1-4): ");
            operacao = int.Parse(Console.ReadLine());

            // Executando a operação escolhida
            if (operacao == 1)
            {
                resultado = num1 + num2;
                Console.WriteLine($"\nResultado da soma: {num1} + {num2} = {resultado}");
            }
            else if (operacao == 2)
            {
                resultado = num1 - num2;
                Console.WriteLine($"\nResultado da subtração: {num1} - {num2} = {resultado}");
            }
            else if (operacao == 3)
            {
                // Verificando divisão por zero
                if (num2 == 0)
                {
                    Console.WriteLine("\nErro: Não é possível dividir por zero!");
                }
                else
                {
                    resultado = num1 / num2;
                    Console.WriteLine($"\nResultado da divisão: {num1} / {num2} = {resultado}");
                }
            }
            else if (operacao == 4)
            {
                resultado = num1 * num2;
                Console.WriteLine($"\nResultado da multiplicação: {num1} * {num2} = {resultado}");
            }
            else
            {
                Console.WriteLine("\nErro: Operação inválida! Escolha um número entre 1 e 4.");
            }
        }
    }
}
