﻿namespace exercicio1_Anderson
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Cadastro de Aluno:");
            Console.Write("Nome: ");
            string nomeAluno = Console.ReadLine();
            Console.Write("Idade: ");
            int idadeAluno = int.Parse(Console.ReadLine());
            Console.Write("Matrícula: ");
            string matricula = Console.ReadLine();
            Aluno aluno = new Aluno(nomeAluno, idadeAluno, matricula);
            aluno.Apresentar();

            Console.WriteLine("\nCadastro de Professor:");
            Console.Write("Nome: ");
            string nomeProfessor = Console.ReadLine();
            Console.Write("Idade: ");
            int idadeProfessor = int.Parse(Console.ReadLine());
            Console.Write("Disciplina: ");
            string disciplina = Console.ReadLine();
            Professor professor = new Professor(nomeProfessor, idadeProfessor, disciplina);
            professor.Apresentar();
        }
    }
}
