﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio1_Anderson
{
    public class Aluno : Pessoa
    {
        public string Matricula;

        public Aluno(string nome, int idade, string matricula) : base(nome, idade)
        {
            Matricula = matricula;
        }

        public override void Apresentar()
        {
            Console.WriteLine("Nome: " + Nome + ", Idade: " + Idade + ", Matrícula: " + Matricula);
        }
    }
}
