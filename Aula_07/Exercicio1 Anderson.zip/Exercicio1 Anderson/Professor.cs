﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio1_Anderson
{
    public class Professor : Pessoa
    {
        public string Disciplina;

        public Professor(string nome, int idade, string disciplina) : base(nome, idade)
        {
            Disciplina = disciplina;
        }

        public override void Apresentar()
        {
            Console.WriteLine("Nome: " + Nome + ", Idade: " + Idade + ", Disciplina: " + Disciplina);
        }
    }
}
