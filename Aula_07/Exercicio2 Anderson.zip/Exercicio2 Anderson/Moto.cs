﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2_Anderson
{
    public class Moto : Veiculo
    {
        public int Cilindrada;

        public Moto(string marca, string modelo, int cilindrada) : base(marca, modelo)
        {
            Cilindrada = cilindrada;
        }

        public override void Dirigir()
        {
            Console.WriteLine("Dirigindo a " + Marca + " " + Modelo + " com " + Cilindrada + " cilindradas");
        }
    }
}
