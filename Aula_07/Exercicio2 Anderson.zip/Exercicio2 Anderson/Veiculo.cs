﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2_Anderson
{
    public abstract class Veiculo
    {
        public string Marca;
        public string Modelo;

        public Veiculo(string marca, string modelo)
        {
            Marca = marca;
            Modelo = modelo;
        }

        public abstract void Dirigir();
    }
}
