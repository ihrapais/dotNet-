﻿namespace Exercicio2_Anderson
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite a marca do carro:");
            string marcaCarro = Console.ReadLine();
            Console.WriteLine("Digite o modelo do carro:");
            string modeloCarro = Console.ReadLine();
            Console.WriteLine("Digite a quantidade de portas do carro:");
            int portas = int.Parse(Console.ReadLine());
            Carro carro = new Carro(marcaCarro, modeloCarro, portas);
            carro.Dirigir();

            Console.WriteLine("Digite a marca da moto:");
            string marcaMoto = Console.ReadLine();
            Console.WriteLine("Digite o modelo da moto:");
            string modeloMoto = Console.ReadLine();
            Console.WriteLine("Digite a cilindrada da moto:");
            int cilindrada = int.Parse(Console.ReadLine());
            Moto moto = new Moto(marcaMoto, modeloMoto, cilindrada);
            moto.Dirigir();
        }

    }
}
