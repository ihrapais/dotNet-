﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2_Anderson
{
    public class Carro : Veiculo
    {
        public int QuantidadeDePortas;

        public Carro(string marca, string modelo, int quantidadeDePortas) : base(marca, modelo)
        {
            QuantidadeDePortas = quantidadeDePortas;
        }

        public override void Dirigir()
        {
            Console.WriteLine("Dirigindo o " + Marca + " " + Modelo + " com " + QuantidadeDePortas + " portas");
        }
    }
}
