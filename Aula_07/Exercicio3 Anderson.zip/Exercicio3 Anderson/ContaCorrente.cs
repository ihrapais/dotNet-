﻿namespace Exercicio3_Anderson
{
    public class ContaCorrente : ContaBancaria
    {
        public ContaCorrente(double saldoInicial) : base(saldoInicial) { }

        public override void Depositar(double valor)
        {
            if (valor > 0)
            {
                Saldo = Saldo + valor;
                Console.WriteLine("Depósito de " + valor + " realizado na conta corrente.");
            }
            else
            {
                Console.WriteLine("Valor inválido para depósito na conta corrente.");
            }
        }

        public override void Sacar(double valor)
        {
            if (valor > 0 && Saldo >= valor)
            {
                Saldo = Saldo - valor;
                Console.WriteLine("Saque de " + valor + " realizado da conta corrente.");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente ou valor inválido na conta corrente.");
            }
        }
    }
}