﻿namespace Exercicio3_Anderson
{
    public abstract class ContaBancaria
    {
        public double Saldo;

        public ContaBancaria(double saldoInicial)
        {
            Saldo = saldoInicial;
        }

        public abstract void Depositar(double valor);
        public abstract void Sacar(double valor);
    }
}