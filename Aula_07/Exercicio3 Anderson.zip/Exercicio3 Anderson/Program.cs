﻿namespace Exercicio3_Anderson
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Cadastro da Conta Corrente
            Console.WriteLine("Cadastro da Conta Corrente:");
            Console.Write("Saldo Inicial: ");
            double saldoInicialCorrente = double.Parse(Console.ReadLine());
            ContaCorrente contaCorrente = new ContaCorrente(saldoInicialCorrente);

            // Operações na Conta Corrente
            Console.WriteLine("Operações na Conta Corrente:");
            Console.Write("Valor para Depositar: ");
            double valorDeposito = double.Parse(Console.ReadLine());
            contaCorrente.Depositar(valorDeposito);
            Console.WriteLine("Saldo Atual: " + contaCorrente.Saldo);

            Console.Write("Valor para Sacar: ");
            double valorSaque = double.Parse(Console.ReadLine());
            contaCorrente.Sacar(valorSaque);
            Console.WriteLine("Saldo Atual: " + contaCorrente.Saldo);

            // Cadastro da Conta Poupança
            Console.WriteLine("\nCadastro da Conta Poupança:");
            Console.Write("Saldo Inicial: ");
            double saldoInicialPoupanca = double.Parse(Console.ReadLine());
            ContaPoupanca contaPoupanca = new ContaPoupanca(saldoInicialPoupanca);

            // Operações na Conta Poupança
            Console.WriteLine("Operações na Conta Poupança:");
            Console.Write("Valor para Depositar: ");
            valorDeposito = double.Parse(Console.ReadLine());
            contaPoupanca.Depositar(valorDeposito);
            Console.WriteLine("Saldo Atual: " + contaPoupanca.Saldo);

            Console.Write("Valor para Sacar: ");
            valorSaque = double.Parse(Console.ReadLine());
            contaPoupanca.Sacar(valorSaque);
            Console.WriteLine("Saldo Atual: " + contaPoupanca.Saldo);
        }
    }
}