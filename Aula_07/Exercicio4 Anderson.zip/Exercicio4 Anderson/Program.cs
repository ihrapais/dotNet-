﻿namespace Exercicio4_Anderson
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Cadastro do Livro
            Console.WriteLine("Cadastro do Livro:");
            Console.Write("Nome do Livro: ");
            string nomeLivro = Console.ReadLine();
            Console.Write("Preço do Livro: ");
            double precoLivro = double.Parse(Console.ReadLine());
            Livro livro = new Livro(nomeLivro, precoLivro);

            // Exibição do Desconto do Livro
            Console.WriteLine("Preço original do livro: " + livro.Preco);
            Console.WriteLine("Preço com desconto (5%): " + livro.CalcularDesconto());

            // Cadastro do Eletrônico
            Console.WriteLine("\nCadastro do Eletrônico:");
            Console.Write("Nome do Eletrônico: ");
            string nomeEletronico = Console.ReadLine();
            Console.Write("Preço do Eletrônico: ");
            double precoEletronico = double.Parse(Console.ReadLine());
            Eletronico eletronico = new Eletronico(nomeEletronico, precoEletronico);

            // Exibição do Desconto do Eletrônico
            Console.WriteLine("Preço original do eletrônico: " + eletronico.Preco);
            Console.WriteLine("Preço com desconto (12.5%): " + eletronico.CalcularDesconto());
        }
    }
}