﻿namespace Exercicio4_Anderson
{
    public abstract class Produto
    {
        public string Nome;
        public double Preco;

        public Produto(string nome, double preco)
        {
            Nome = nome;
            Preco = preco;
        }

        public abstract double CalcularDesconto();
    }
}