﻿namespace Exercicio4_Anderson
{
    public class Eletronico : Produto
    {
        public Eletronico(string nome, double preco) : base(nome, preco) { }

        public override double CalcularDesconto()
        {
            double desconto = Preco * 0.125; // 12.5% de desconto
            return Preco - desconto;
        }
    }
}