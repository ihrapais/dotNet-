﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aluno
{
    internal class Aluno
    {
        public string Nome;
        public int Matricula;
        public string Curso;

        public Aluno(string nome, int matricula, string curso)
        {
            Nome = nome;
            Matricula = matricula;
            Curso = curso;
        }

        public void Apresentar()
        {
            Console.WriteLine("Nome: " + Nome + ", Matrícula: " + Matricula + ", Curso: " + Curso);
        }
    }
}
