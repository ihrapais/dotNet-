﻿namespace Aluno
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o nome do aluno:");
            string nome = Console.ReadLine();
            Console.WriteLine("Digite a matrícula:");
            int matricula = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o curso:");
            string curso = Console.ReadLine();

            Aluno aluno = new Aluno(nome, matricula, curso);
            aluno.Apresentar();
        }
    }
}
