﻿namespace Livro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o título do primeiro livro:");
            string titulo1 = Console.ReadLine();
            Console.WriteLine("Digite o autor:");
            string autor1 = Console.ReadLine();
            Console.WriteLine("Digite o ano de publicação:");
            int ano1 = int.Parse(Console.ReadLine());
            Livro livro1 = new Livro(titulo1, autor1, ano1);

            Console.WriteLine("Digite o título do segundo livro:");
            string titulo2 = Console.ReadLine();
            Console.WriteLine("Digite o autor:");
            string autor2 = Console.ReadLine();
            Console.WriteLine("Digite o ano de publicação:");
            int ano2 = int.Parse(Console.ReadLine());
            Livro livro2 = new Livro(titulo2, autor2, ano2);

            Console.WriteLine("Digite 1 para emprestar ou 2 para devolver o livro " + livro1.Titulo + ":");
            int opcao1 = int.Parse(Console.ReadLine());
            if (opcao1 == 1) livro1.Emprestar();
            else if (opcao1 == 2) livro1.Devolver();

            Console.WriteLine("Digite 1 para emprestar ou 2 para devolver o livro " + livro2.Titulo + ":");
            int opcao2 = int.Parse(Console.ReadLine());
            if (opcao2 == 1) livro2.Emprestar();
            else if (opcao2 == 2) livro2.Devolver();
        }
    }
}
