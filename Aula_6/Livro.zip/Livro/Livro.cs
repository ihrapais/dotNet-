﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Livro
{
    internal class Livro
    {
        public string Titulo;
        public string Autor;
        public int AnoPublicacao;
        public bool Emprestado;

        public Livro(string titulo, string autor, int ano)
        {
            Titulo = titulo;
            Autor = autor;
            AnoPublicacao = ano;
            Emprestado = false;
        }

        public void Emprestar()
        {
            if (!Emprestado)
            {
                Emprestado = true;
                Console.WriteLine("Livro " + Titulo + " foi emprestado.");
            }
            else
            {
                Console.WriteLine("O livro " + Titulo + " já está emprestado!");
            }
        }

        public void Devolver()
        {
            if (Emprestado)
            {
                Emprestado = false;
                Console.WriteLine("Livro " + Titulo + " foi devolvido.");
            }
            else
            {
                Console.WriteLine("O livro " + Titulo + " já está na biblioteca!");
            }
        }
    }
}
