﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personagem
{
    internal class Personagem
    {
        public string Nome;
        public string Posicao;
        public int ItensColetados;

        public Personagem(string nome, string posicao, int itens)
        {
            Nome = nome;
            Posicao = posicao;
            ItensColetados = itens;
        }

        public void Atacar(double dano)
        {
            if (dano >= 0 && dano <= 10)
            {
                Console.WriteLine(Nome + " atacou causando " + dano + " de dano!");
            }
            else
            {
                Console.WriteLine("Dano inválido! Deve estar entre 0 e 10.");
            }
        }

        public void Movimentar(int direcao)
        {
            switch (direcao)
            {
                case 1:
                    Console.WriteLine(Nome + " se moveu para frente!");
                    break;
                case 2:
                    Console.WriteLine(Nome + " se moveu para trás!");
                    break;
                case 3:
                    Console.WriteLine(Nome + " se moveu para a direita!");
                    break;
                case 4:
                    Console.WriteLine(Nome + " se moveu para a esquerda!");
                    break;
                default:
                    Console.WriteLine("Direção inválida!");
                    break;
            }
        }
    }
}
