﻿namespace Personagem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o nome do personagem:");
            string nome = Console.ReadLine();
            Console.WriteLine("Digite a posição inicial:");
            string posicao = Console.ReadLine();
            Console.WriteLine("Digite a quantidade de itens coletados:");
            int itens = int.Parse(Console.ReadLine());

            Personagem p = new Personagem(nome, posicao, itens);

            // Exibindo os dados do personagem após a criação
            Console.WriteLine("\nPersonagem criado:");
            Console.WriteLine("Nome: " + p.Nome);
            Console.WriteLine("Posição: " + p.Posicao);
            Console.WriteLine("Itens coletados: " + p.ItensColetados);

            // Solicitando e executando o ataque
            Console.WriteLine("\nDigite o dano do ataque (0 a 10):");
            double dano = double.Parse(Console.ReadLine());
            p.Atacar(dano);

            // Solicitando e executando o movimento
            Console.WriteLine("Digite a direção (1-frente, 2-trás, 3-direita, 4-esquerda):");
            int direcao = int.Parse(Console.ReadLine());
            p.Movimentar(direcao);
        }
    }
}
