﻿namespace Livro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Criando uma lista para armazenar os livros
            List<Livro> livros = new List<Livro>();

            // Preenchendo os três primeiros livros obrigatórios
            for (int i = 1; i <= 3; i++)
            {
                Console.WriteLine($"\nDigite os dados do Livro {i}:");
                Livro novoLivro = new Livro();

                Console.Write("Título: ");
                novoLivro.Titulo = Console.ReadLine();

                Console.Write("Autor: ");
                novoLivro.Autor = Console.ReadLine();

                Console.Write("Ano de Publicação: ");
                novoLivro.AnoPublicacao = int.Parse(Console.ReadLine());

                livros.Add(novoLivro);
            }

            // Perguntando se o usuário quer adicionar mais livros
            char resposta;
            do
            {
                Console.Write("\nDeseja adicionar mais um livro? (S/N): ");
                resposta = char.ToUpper(Console.ReadLine()[0]);

                if (resposta == 'S')
                {
                    Console.WriteLine($"\nDigite os dados do Livro {livros.Count + 1}:");
                    Livro novoLivro = new Livro();

                    Console.Write("Título: ");
                    novoLivro.Titulo = Console.ReadLine();

                    Console.Write("Autor: ");
                    novoLivro.Autor = Console.ReadLine();

                    Console.Write("Ano de Publicação: ");
                    novoLivro.AnoPublicacao = int.Parse(Console.ReadLine());

                    livros.Add(novoLivro);
                }
            } while (resposta == 'S');

            // Exibindo as informações de todos os livros
            Console.WriteLine("\n=== Informações dos Livros ===");
            for (int i = 0; i < livros.Count; i++)
            {
                Console.WriteLine($"\nLivro {i + 1}:");
                Console.WriteLine($"Título: {livros[i].Titulo}");
                Console.WriteLine($"Autor: {livros[i].Autor}");
                Console.WriteLine($"Ano de Publicação: {livros[i].AnoPublicacao}");
            }
        }
    }
}