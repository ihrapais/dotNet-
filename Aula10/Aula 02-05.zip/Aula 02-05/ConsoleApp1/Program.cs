﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pessoa P = new Pessoa();

            P.Nome = "Anderson";
                
            Console.WriteLine("Nome da pessoa: " + P.Nome);
            try
            {
                P.Nome = "";
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exceção lançada: " + ex.Message);
            }

            //Chamando o getter da propriedade
            Console.WriteLine("Nome da pessoa: " + P.Nome);

            try
            {
                P.Idade = -14;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exceção Lançada: " + ex.Message);
            }

            Console.WriteLine("Idade: " + P.Idade);

            Produto produto = new Produto();
            produto.Nome = "Produto 1";
            produto.Preco = 10.50;
            produto.Imposto = 0.7;
            Console.WriteLine("Produto: " + produto.Nome);
            Console.WriteLine("Preço: " + produto.Preco);
            Console.WriteLine("Preço Final: " + produto.PrecoFinal);
        }
    }
}