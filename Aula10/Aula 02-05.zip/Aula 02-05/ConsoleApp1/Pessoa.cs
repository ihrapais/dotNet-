﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Pessoa
    {
        private string _nome;
        private int _idade;

        public int Idade
        {
            get
            {
                return _idade;
            }
            set
            {
                if (value < 0)
                {
                    throw new Exception("Idade não pode ser menor que 0");
                }
                _idade = value;
            }
        }
    public string Nome
        {
            get
            {
                return _nome;

            }

            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("Nome não pode ser vazio");
                }
                {
                    _nome = value;
                }
            }
        }
    }
  
}
