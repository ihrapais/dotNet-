﻿namespace Carro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Criando o primeiro carro
            Carro carro1 = new Carro();
            Console.WriteLine("Preencha os dados do Carro 1:");
            Console.Write("Marca: ");
            carro1.marca = Console.ReadLine();
            Console.Write("Modelo: ");
            carro1.modelo = Console.ReadLine();
            Console.Write("Ano de Fabricação: ");
            carro1.anoFabricacao = int.Parse(Console.ReadLine());
            Console.WriteLine();

            // Criando o segundo carro
            Carro carro2 = new Carro();
            Console.WriteLine("Preencha os dados do Carro 2:");
            Console.Write("Marca: ");
            carro2.marca = Console.ReadLine();
            Console.Write("Modelo: ");
            carro2.modelo = Console.ReadLine();
            Console.Write("Ano de Fabricação: ");
            carro2.anoFabricacao = int.Parse(Console.ReadLine());
            Console.WriteLine();

            // Exibindo os dados dos dois carros
            Console.WriteLine("=== Dados dos Carros ===");
            Console.WriteLine("Carro 1:");
            Console.WriteLine($"Marca: {carro1.marca}");
            Console.WriteLine($"Modelo: {carro1.modelo}");
            Console.WriteLine($"Ano de Fabricação: {carro1.anoFabricacao}");

            Console.WriteLine("\nCarro 2:");
            Console.WriteLine($"Marca: {carro2.marca}");
            Console.WriteLine($"Modelo: {carro2.modelo}");
            Console.WriteLine($"Ano de Fabricação: {carro2.anoFabricacao}");
        }
    }
}