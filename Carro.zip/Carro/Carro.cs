﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carro
{
    internal class Carro
    {
        public string marca;
        public string modelo;
        public int anoFabricacao;
    }

}
