﻿namespace Jogo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Jogo jogo = new Jogo();

            Console.WriteLine("Digite o título do jogo:");
            jogo.Titulo = Console.ReadLine();

            Console.WriteLine("Digite o gênero do jogo:");
            jogo.Genero = Console.ReadLine();

            Console.WriteLine("Digite a plataforma do jogo:");
            jogo.Plataforma = Console.ReadLine();

            Console.WriteLine("Digite o ano de lançamento:");
            jogo.AnoLancamento = int.Parse(Console.ReadLine());

            // Exibindo os dados inseridos
            Console.WriteLine("\nDados do Jogo:");
            Console.WriteLine("Título: " + jogo.Titulo);
            Console.WriteLine("Gênero: " + jogo.Genero);
            Console.WriteLine("Plataforma: " + jogo.Plataforma);
            Console.WriteLine("Ano de Lançamento: " + jogo.AnoLancamento);
        }
    }
}