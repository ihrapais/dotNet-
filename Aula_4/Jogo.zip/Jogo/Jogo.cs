﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jogo
{
    internal class Jogo
    {
        public string Titulo;
        public string Genero;
        public string Plataforma;
        public int AnoLancamento;
    }
}
