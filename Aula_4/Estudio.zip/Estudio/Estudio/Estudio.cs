﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estudio
{
    internal class Estudio
    {
        public string Nome;
        public int AnoFundacao;
        public string PaisOrigem;
        public int NumeroJogos;
    }

}
