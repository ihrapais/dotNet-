﻿namespace Estudio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Estudio estudio = new Estudio();

            Console.WriteLine("Digite o nome do estúdio:");
            estudio.Nome = Console.ReadLine();

            Console.WriteLine("Digite o ano de fundação:");
            estudio.AnoFundacao = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o país de origem:");
            estudio.PaisOrigem = Console.ReadLine();

            Console.WriteLine("Digite o número de jogos produzidos:");
            estudio.NumeroJogos = int.Parse(Console.ReadLine());

            // Exibindo os dados inseridos
            Console.WriteLine("\nDados do Estúdio:");
            Console.WriteLine("Nome: " + estudio.Nome);
            Console.WriteLine("Ano de Fundação: " + estudio.AnoFundacao);
            Console.WriteLine("País de Origem: " + estudio.PaisOrigem);
            Console.WriteLine("Número de Jogos: " + estudio.NumeroJogos);
        }
    }
}