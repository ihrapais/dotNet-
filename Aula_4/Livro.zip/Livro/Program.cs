﻿namespace Livro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Criando o primeiro livro
            Console.WriteLine("Digite os dados do Livro 1:");
            Livro livro1 = new Livro();
            Console.Write("Título: ");
            livro1.Titulo = Console.ReadLine();
            Console.Write("Autor: ");
            livro1.Autor = Console.ReadLine();
            Console.Write("Ano de Publicação: ");
            livro1.AnoPublicacao = int.Parse(Console.ReadLine());

            // Criando o segundo livro
            Console.WriteLine("\nDigite os dados do Livro 2:");
            Livro livro2 = new Livro();
            Console.Write("Título: ");
            livro2.Titulo = Console.ReadLine();
            Console.Write("Autor: ");
            livro2.Autor = Console.ReadLine();
            Console.Write("Ano de Publicação: ");
            livro2.AnoPublicacao = int.Parse(Console.ReadLine());

            // Criando o terceiro livro
            Console.WriteLine("\nDigite os dados do Livro 3:");
            Livro livro3 = new Livro();
            Console.Write("Título: ");
            livro3.Titulo = Console.ReadLine();
            Console.Write("Autor: ");
            livro3.Autor = Console.ReadLine();
            Console.Write("Ano de Publicação: ");
            livro3.AnoPublicacao = int.Parse(Console.ReadLine());

            // Exibindo as informações dos livros
            Console.WriteLine("\n=== Informações dos Livros ===");
            Console.WriteLine("\nLivro 1:");
            Console.WriteLine($"Título: {livro1.Titulo}");
            Console.WriteLine($"Autor: {livro1.Autor}");
            Console.WriteLine($"Ano de Publicação: {livro1.AnoPublicacao}");

            Console.WriteLine("\nLivro 2:");
            Console.WriteLine($"Título: {livro2.Titulo}");
            Console.WriteLine($"Autor: {livro2.Autor}");
            Console.WriteLine($"Ano de Publicação: {livro2.AnoPublicacao}");

            Console.WriteLine("\nLivro 3:");
            Console.WriteLine($"Título: {livro3.Titulo}");
            Console.WriteLine($"Autor: {livro3.Autor}");
            Console.WriteLine($"Ano de Publicação: {livro3.AnoPublicacao}");
        }
    }
}