﻿using System;

internal class Pessoa
{
    public string Nome, CPF, RG;
    public DateTime DataNascimento;

    // Método para cadastrar os dados
    public void Cadastrar()
    {
        Console.WriteLine("=== Cadastro de Pessoa ===");
        Console.Write("Digite o nome: ");
        Nome = Console.ReadLine();

        Console.Write("Digite o CPF: ");
        CPF = Console.ReadLine();

        Console.Write("Digite a data de nascimento (ex: 01/01/2000): ");
        DataNascimento = DateTime.Parse(Console.ReadLine());

        Console.Write("Digite o RG: ");
        RG = Console.ReadLine();
    }

    // Método para apresentar os dados
    public void Apresentar()
    {
        Console.WriteLine("\n=== Dados da Pessoa ===");
        Console.WriteLine($"Nome: {Nome}");
        Console.WriteLine($"CPF: {CPF}");
        Console.WriteLine($"Data de Nascimento: {DataNascimento}");
        Console.WriteLine($"RG: {RG}");
    }
}

