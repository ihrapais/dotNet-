﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
internal class Program
{
    static void Main(string[] args)
    {
        // Criando um objeto da classe Pessoa
        Pessoa pessoa = new Pessoa();

        // Chamando o método para cadastrar os dados
        pessoa.Cadastrar();

        // Chamando o método para apresentar os dados
        pessoa.Apresentar();
    }
}